package com.example.instagram_follow_unfollow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
