

import 'package:flutter/cupertino.dart';

class User {
  final String name;
  final String username;
  final String imageUrl;
  bool isFollowed;

  User (
      {required this.name,
    required this.username,
    required this.imageUrl,
        required this.isFollowed
      });
}
List<User> usersList = [


  User(name: 'Shahid Afridi', username: "Lala",
      imageUrl:  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIxGNSaQuBieJrqfd30lVMmR5O73m1zHT7Eg&s"
      , isFollowed: false),

  User(name: 'Glenn Maxwell', username: "Maxwell",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm55YNDH_bVzl6qcDzdsYm9bvT1nPUKKxanA&s'
      , isFollowed: false),

  User(name: 'Virat Kohli', username: "Kohli",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShsXDeEAtDQ5515onMCGzmoWzZoyM7kvSa1w&s'
      , isFollowed: false),

  User(name: 'ronaldo', username: "Cr7",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMtkTXlAwv_txxifQ2tSvgn7ACteAIgSpLgw&s'
      , isFollowed: false),

  User(name: 'Dean Elgar', username: "Dean",
      imageUrl: 'https://content.api.news/v3/images/bin/fec961e4fc59918613336d9d7ce07c37?width=1024'
      , isFollowed: false),

  User(name: 'Shahid Afridi', username: "Lala",
      imageUrl:  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIxGNSaQuBieJrqfd30lVMmR5O73m1zHT7Eg&s"
      , isFollowed: false),

  User(name: 'Glenn Maxwell', username: "Maxwell",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm55YNDH_bVzl6qcDzdsYm9bvT1nPUKKxanA&s'
      , isFollowed: false),

  User(name: 'Virat Kohli', username: "Kohli",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShsXDeEAtDQ5515onMCGzmoWzZoyM7kvSa1w&s'
      , isFollowed: false),

  User(name: 'ronaldo', username: "Cr7",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMtkTXlAwv_txxifQ2tSvgn7ACteAIgSpLgw&s'
      , isFollowed: false),

  User(name: 'Dean Elgar', username: "Dean",
      imageUrl: 'https://content.api.news/v3/images/bin/fec961e4fc59918613336d9d7ce07c37?width=1024'
      , isFollowed: false),

  User(name: 'Shahid Afridi', username: "Lala",
      imageUrl:  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIxGNSaQuBieJrqfd30lVMmR5O73m1zHT7Eg&s"
      , isFollowed: false),

  User(name: 'Glenn Maxwell', username: "Maxwell",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTm55YNDH_bVzl6qcDzdsYm9bvT1nPUKKxanA&s'
      , isFollowed: false),

  User(name: 'Virat Kohli', username: "Kohli",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShsXDeEAtDQ5515onMCGzmoWzZoyM7kvSa1w&s'
      , isFollowed: false),

  User(name: 'ronaldo', username: "Cr7",
      imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMtkTXlAwv_txxifQ2tSvgn7ACteAIgSpLgw&s'
      , isFollowed: false),

  User(name: 'Dean Elgar', username: "Dean",
      imageUrl: 'https://content.api.news/v3/images/bin/fec961e4fc59918613336d9d7ce07c37?width=1024'
      , isFollowed: false),

];