

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Grid_Menu extends StatefulWidget {
  const Grid_Menu({super.key});

  @override
  State<Grid_Menu> createState() => _Grid_MenuState();
}

class _Grid_MenuState extends State<Grid_Menu> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: ListView.builder(
          shrinkWrap: true,
          itemCount: 10,
          itemBuilder: (context , index){

        return Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [

                Container(
                  height: 210,
                  width: 170,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [

                        BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            blurRadius: 05,
                            spreadRadius: 5,
                            offset: Offset(5, 5))
                      ]
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 170,
                        decoration: BoxDecoration(

                            image: DecorationImage(
                                fit: BoxFit.fitWidth,
                                image: AssetImage('assets/arabian burger.png'))
                        ),
                      ),
                      SizedBox(height: 1,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Arabian Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),


                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text(
                                  "Rs 350",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.deepOrange),
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.deepOrange,
                                  radius: 15,
                                  child: Icon(Icons.add,color: Colors.white,),
                                )

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 210,
                  width: 170,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [

                        BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            blurRadius: 05,
                            spreadRadius: 5,
                            offset: Offset(5, 5))
                      ]
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 170,
                        decoration: BoxDecoration(

                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage('assets/fajita pizza.png'))
                        ),
                      ),
                      SizedBox(height: 1,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Chicken Fajita",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),


                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text(
                                  "Rs 350-1850",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.deepOrange),
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.deepOrange,
                                  radius: 15,
                                  child: Icon(Icons.add,color: Colors.white,),
                                )

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [

                Container(
                  height: 210,
                  width: 170,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [

                        BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            blurRadius: 05,
                            spreadRadius: 5,
                            offset: Offset(5, 5))
                      ]
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 170,
                        decoration: BoxDecoration(

                            image: DecorationImage(
                                fit: BoxFit.fitWidth,
                                image: AssetImage('assets/arabian burger.png'))
                        ),
                      ),
                      SizedBox(height: 1,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Arabian Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),


                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text(
                                  "Rs 350",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.deepOrange),
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.deepOrange,
                                  radius: 15,
                                  child: Icon(Icons.add,color: Colors.white,),
                                )

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 210,
                  width: 170,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [

                        BoxShadow(
                            color: Colors.grey.withOpacity(0.1),
                            blurRadius: 05,
                            spreadRadius: 5,
                            offset: Offset(5, 5))
                      ]
                  ),
                  child: Column(
                    children: [
                      Container(
                        height: 120,
                        width: 170,
                        decoration: BoxDecoration(

                            image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage('assets/fajita pizza.png'))
                        ),
                      ),
                      SizedBox(height: 1,),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 7),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Chicken Fajita",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [

                                Text(
                                  "Burger",
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.normal),
                                ),


                              ],
                            ),
                            SizedBox(height: 1,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text(
                                  "Rs 350-1850",
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.deepOrange),
                                ),
                                CircleAvatar(
                                  backgroundColor: Colors.deepOrange,
                                  radius: 15,
                                  child: Icon(Icons.add,color: Colors.white,),
                                )

                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 10,),


          ],
        );
      })
    );
  }
}
