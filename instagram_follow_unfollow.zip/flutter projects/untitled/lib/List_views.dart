import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ionicons/ionicons.dart';
import 'package:untitled/List_views.dart';

class List_View extends StatefulWidget {
  const List_View({super.key});

  @override
  State<List_View> createState() => _List_ViewState();
}

class _List_ViewState extends State<List_View> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Column(

        children: [
          Row(
            children: [
              Container(
                height: 100,
                width: 360,
                decoration: BoxDecoration(
                    color: Color.fromRGBO(255, 178, 107, 0.25),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    SizedBox(width: 5,),
                    Container(

                      height: 90,
                      width: 120,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("assets/arabian burger.png"))),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            "Arabian Burger",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Burger",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Rs 350",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    Container(
                      height: 93,
                      width: 60,
                      decoration: BoxDecoration(
                        color: Color.fromRGBO(255, 123, 84, 1),
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(50),bottomLeft: Radius.circular(50), topRight:Radius.circular(10) , bottomRight: Radius.circular(10) )
                      ),
                      child: Center(child: Icon(Icons.add,color: Colors.white, size: 30,)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 8,
          ),
          Row(
            children: [
              Container(
                height: 100,
                width: 360,
                decoration: BoxDecoration(
                    color: Color.fromRGBO(255, 178, 107, 0.25),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    SizedBox(width: 5,),
                    Container(
                      height: 90,
                      width: 120,

                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                            fit: BoxFit.cover,
                              image: AssetImage("assets/fajita pizza.png")),
                    )),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            "Chicken Fajita",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Pizza",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Rs 350-1850",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    Container(
                      height: 93,
                      width: 60,
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(50),bottomLeft: Radius.circular(50), topRight:Radius.circular(10) , bottomRight: Radius.circular(10) )
                      ),
                      child: Center(child: Icon(Icons.add,color: Colors.white, size: 30,)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              Container(
                height: 100,
                width: 360,
                decoration: BoxDecoration(
                    color: Color.fromRGBO(255, 178, 107, 0.25),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    SizedBox(width: 5,),
                    Container(

                      height: 90,
                      width: 120,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("assets/arabian burger.png"))),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            "Arabian Burger",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Burger",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Rs 350",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    Container(
                      height: 93,
                      width: 60,
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(50),bottomLeft: Radius.circular(50), topRight:Radius.circular(10) , bottomRight: Radius.circular(10) )
                      ),
                      child: Center(child: Icon(Icons.add,color: Colors.white, size: 30,)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 8,
          ),
          Row(
            children: [
              Container(
                height: 100,
                width: 360,
                decoration: BoxDecoration(
                    color: Color.fromRGBO(255, 178, 107, 0.25),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    SizedBox(width: 5,),
                    Container(
                        height: 90,
                        width: 120,

                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("assets/fajita pizza.png")),
                        )),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            "Chicken Fajita",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Pizza",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Rs 350-1850",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    Container(
                      height: 93,
                      width: 60,
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(50),bottomLeft: Radius.circular(50), topRight:Radius.circular(10) , bottomRight: Radius.circular(10) )
                      ),
                      child: Center(child: Icon(Icons.add,color: Colors.white, size: 30,)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              Container(
                height: 100,
                width: 360,
                decoration: BoxDecoration(
                    color: Color.fromRGBO(255, 178, 107, 0.25),
                    borderRadius: BorderRadius.circular(14)),
                child: Row(
                  children: [
                    SizedBox(width: 5,),
                    Container(

                      height: 90,
                      width: 120,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage("assets/arabian burger.png"))),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Container(
                      width: 150,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                          Text(
                            "Arabian Burger",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            "Burger",
                            style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Rs 350",
                            style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange),
                          )
                        ],
                      ),
                    ),
                    SizedBox(width: 20,),
                    Container(
                      height: 93,
                      width: 60,
                      decoration: BoxDecoration(
                          color: Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.only(topLeft: Radius.circular(50),bottomLeft: Radius.circular(50), topRight:Radius.circular(10) , bottomRight: Radius.circular(10) )
                      ),
                      child: Center(child: Icon(Icons.add,color: Colors.white, size: 30,)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 8,
          ),


        ],
      ),
    );
  }
}
