import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:ionicons/ionicons.dart';
import 'package:untitled/List_views.dart';

import 'Grid_View.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          "Home",
          style: TextStyle(color: Colors.deepOrangeAccent),
        ),
        actions: [
          Container(
            height: 30,
            width: 30,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.blue, width: 1),
            ),
            child: Icon(
              Icons.add_shopping_cart_outlined,
              color: Colors.deepOrange,
            ),
          ),
          SizedBox(
            width: 20,
          )
        ],
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(40)
        ),
        onPressed: (){

      },
        child: Center(child: Icon(Icons.add,color: Colors.white,)),
      backgroundColor: Colors.deepOrange,),
      bottomNavigationBar: Container(
        height: 100,
        width: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(topLeft: Radius.circular(60,),topRight: Radius.circular(60)),
          boxShadow: [
            BoxShadow(
        color: Colors.grey.withOpacity(0.1),
          blurRadius: 08,
          spreadRadius: 5,
          offset: Offset(5, 0.8)
            )
          ],
          color: Colors.white
        ),
        child: BottomNavigationBar(

            items:  const [
         BottomNavigationBarItem(icon: Icon(Icons.grid_view_outlined,color: Colors.black,),label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.foggy, color: Color.fromRGBO(255, 178, 107, 0.25),size: 30,), label: ''),
          BottomNavigationBarItem(icon: Icon(Icons.list_outlined,color: Colors.black,size: 30,), label: ''),
              BottomNavigationBarItem(icon: Icon(Icons.person,size: 30,color: Colors.black,), label: ''),

        ]),
      ),

      body: Column(

              children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            Container(
              height: 45,
              width: 80,
              decoration: BoxDecoration(
                  color: Colors.deepOrange,
                  borderRadius: BorderRadius.circular(50)),
              child: Center(
                  child: Text(
                "All",
                style: TextStyle(color: Colors.white),
              )),
            ),
            SizedBox(
              width: 5,
            ),
            Container(
              height: 45,
              width: 80,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.deepOrange),
                  borderRadius: BorderRadius.circular(50)),
              child: Center(
                child: Row(
                  children: [
                    SizedBox(
                      width: 4,
                    ),
                    Icon(
                      Icons.local_pizza_outlined,
                      color: Colors.deepOrange,
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      "Pizza",
                      style: TextStyle(color: Colors.deepOrange),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 5,
            ),
            Container(
              height: 45,
              width: 110,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.deepOrange),
                  borderRadius: BorderRadius.circular(50)),
              child: Center(
                child: Row(
                  children: [
                    SizedBox(
                      width: 4,
                    ),
                    Icon(
                      Icons.emoji_food_beverage,
                      color: Colors.deepOrange,
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      "Appetizer",
                      style: TextStyle(color: Colors.deepOrange),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              width: 5,
            ),
            Container(
              height: 45,
              width: 110,
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.deepOrange),
                  borderRadius: BorderRadius.circular(50)),
              child: Center(
                child: Row(
                  children: [
                    SizedBox(
                      width: 4,
                    ),
                    Icon(
                      Icons.cloud_upload,
                      color: Colors.deepOrange,
                    ),
                    SizedBox(
                      width: 4,
                    ),
                    Text(
                      "Sandwich",
                      style: TextStyle(color: Colors.deepOrange),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      SizedBox(
        height: 20,
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              IconButton(
                  onPressed: () {},
                  icon: Icon(Icons.list_alt,
                      color: Colors.deepOrange, size: 30)),
              IconButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => Grid_View()));
                },
                icon: Icon(Icons.grid_view_outlined,
                    color: Colors.deepOrange, size: 30),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 35,
                width: 35,
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.deepOrange)),
                child: Container(
                  height: 35,
                  width: 35,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      color: Colors.deepOrange),
                  child: Icon(
                    Icons.expand_more_sharp,
                    color: Colors.white,
                  ),
                ),
              ),
              SizedBox(
                width: 10,
              ),
              Container(
                height: 35,
                width: 35,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: Colors.deepOrange),
                child: Icon(
                  Icons.search,
                  color: Colors.white,
                  size: 19,
                ),
              ),
            ],
          )
        ],
      ),
      List_View()
              ],
            ),
    );
  }
}
