package com.example.cherry_food

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
