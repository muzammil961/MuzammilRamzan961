import 'package:cherry_food/Add%20to%20cart/Cart_Model.dart';
import 'package:cherry_food/Add%20to%20cart/Network_image.dart';
import 'package:flutter/material.dart';
import 'package:persistent_shopping_cart/model/cart_model.dart';
import 'package:persistent_shopping_cart/persistent_shopping_cart.dart';

class List_Screen extends StatefulWidget {
  const List_Screen({super.key});

  @override
  State<List_Screen> createState() => _List_ScreenState();
}

class _List_ScreenState extends State<List_Screen> {

  PersistentShoppingCart cart = PersistentShoppingCart();
bool? isChecked = false;

  List<ItemModel> itemsList = const [
    ItemModel(
        productId: '1',
        productName: 'Arabian Burger',
        productDescription: 'Burger',
        productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
        unitPrice: 350),
    ItemModel(
        productId: '2',
        productName: 'Chicken Fajita',
        productDescription: 'Pizza',
        productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
        unitPrice: 350),
    ItemModel(
        productId: '3',
        productName: 'Arabian Burger',
        productDescription: 'Burger',
        productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
        unitPrice: 350),
    ItemModel(
        productId: '4',
        productName: 'Chicken Fajita',
        productDescription: 'Pizza',
        productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
        unitPrice: 350),
    ItemModel(
        productId: '5',
        productName: 'Arabian Burger',
        productDescription: 'Burger',
        productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
        unitPrice: 350),
    ItemModel(
        productId: '6',
        productName: 'Chicken Fajita',
        productDescription: 'Pizza',
        productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
        unitPrice: 350),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
            child: ListView.builder(
                itemCount: itemsList.length,
                itemBuilder: (context, index) {
                  final item = itemsList[index];
                  return Card(
                      color: const Color.fromRGBO(255, 178, 107, 0.6),
                    child: Padding(
                      padding: const EdgeInsets.all(5),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              NetworkImageWidget(
                                  height: 100,
                                  width: 100,
                                  imageUrl: item.productThumbnail),
                              const SizedBox(
                                width: 10,
                              ),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      item.productName,
                                      style: const TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      item.productDescription,
                                      style: const TextStyle(
                                        fontSize: 14,
                                      ),
                                    ),
                                    Text(
                                      r"Rs " + item.unitPrice.toString(),
                                      style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),

                                  ],
                                ),
                              ),

                              Container(
                                height: MediaQuery.of(context).size.height *0.1,
                                width: MediaQuery.of(context).size.width* 0.17,
                                decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.only(topLeft: Radius.circular(60),bottomLeft: Radius.circular(60),bottomRight: Radius.circular(10),topRight: Radius.circular(10)),
                                  color: Colors.deepOrange
                                ),
                                child:  Center(child: TextButton(onPressed: _SelectedDialouge, child: Icon(Icons.add,size: 30,))
                                )
                              )

                            ],
                          )
                        ],
                      ),
                    ),
                  );
                }))
      ],
    );
  }

 void _SelectedDialouge() {
    showDialog(context: context, builder:(BuildContext context) {
      return AlertDialog(

       backgroundColor: Colors.white,
       title: Column(
         children: [
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
             children: [
               Row(
                 children: [
                   Checkbox(
                       value: isChecked,
                       activeColor: Colors.deepOrange,
                       tristate: true,
                       onChanged: (newBool){
                         setState(() {
                           isChecked = newBool;
                         });
                       }),
                   Text('Small'),
                 ],
               ),
               Text('390')
             ],
           )
         ],
       ),
      );
    });
 }
}

