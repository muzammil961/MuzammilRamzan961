// PersistentShoppingCart()
//     .showAndUpdateCartItemWidget(
// inCartWidget: const Text('-',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25),),
// notInCartWidget:
// const Text('+',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 25),),
// product: PersistentShoppingCartItem(
// productId: item.productId,
// productName: item.productName,
// unitPrice: double.parse(
// item.unitPrice.toString()),
// quantity: 1,
// productThumbnail:
// item.productThumbnail,
// productDescription: item.productDescription)),