import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class Customer_List extends StatefulWidget {
  const Customer_List({super.key});

  @override
  State<Customer_List> createState() => _Customer_ListState();
}

class _Customer_ListState extends State<Customer_List> {
  File? _pickedImage;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
      ),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(40),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    Container(
                      height: 150,
                      width: 200,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: const [
                            BoxShadow(blurRadius: 3, offset: Offset(0, 3))
                          ],
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    Positioned(
                      bottom: 20,
                      top: 20,
                      right: 20,
                      left: 20,
                      child: Center(
                        child: GestureDetector(
                          onTap: () {
                            // Implement your image picking logic here
                          },
                          child: Container(
                            height: 120,
                            width: 200,
                            decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(100)),
                            ),
                            child: _pickedImage == null
                                ? const CircleAvatar(
                                    backgroundImage: AssetImage(
                                        ''), // Placeholder image asset
                                  )
                                : CircleAvatar(
                                    backgroundImage: FileImage(
                                        _pickedImage!), // Display picked image
                                  ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 100,
                    ),
                    Positioned(
                      right: 48,
                      top: 100,
                      child: InkWell(
                        onTap: () {
                          showImagePicker(context);
                        },
                        child: Container(
                          height: 30,
                          width: 30,
                          alignment: Alignment.bottomRight,
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.deepOrange),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20)),
                          child: const Center(
                              child: Icon(
                            Icons.camera_alt_outlined,
                            color: Colors.deepOrange,
                            size: 20,
                          )),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              TextFormField(
                cursorColor: Colors.deepOrange,
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  labelText: 'Full Name',
                  hintText: "Enter Name",
                  suffixIcon: InkWell(
                      child: Icon(
                    Icons.border_color,
                    color: Color.fromRGBO(255, 123, 84, 1),
                  )),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                ),
              ),
              const SizedBox(
                height: 14,
              ),
              TextFormField(
                cursorColor: Colors.deepOrange,
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  labelText: 'Phone Number',
                  hintText: "Enter Phone Number",
                  suffixIcon: InkWell(
                      child: Icon(
                    Icons.border_color,
                    color: Color.fromRGBO(255, 123, 84, 1),
                  )),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                ),
              ),
              const SizedBox(
                height: 14,
              ),
              TextFormField(
                cursorColor: Colors.deepOrange,
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  labelText: 'Password',
                  hintText: "*********",
                  suffixIcon: InkWell(
                      child: Icon(
                    Icons.border_color,
                    color: Color.fromRGBO(255, 123, 84, 1),
                  )),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                ),
              ),
              const SizedBox(
                height: 14,
              ),
              TextFormField(
                cursorColor: Colors.deepOrange,
                decoration: const InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  labelText: 'Address',
                  hintText: "Town, City, Country",
                  suffixIcon: InkWell(
                      child: Icon(
                    Icons.border_color,
                    color: Color.fromRGBO(255, 123, 84, 1),
                  )),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.deepOrange),
                      borderRadius: BorderRadius.all(Radius.circular(5))),
                ),
              ),
              const SizedBox(
                height: 24,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                      height: 35,
                      width: 70,
                      decoration: BoxDecoration(
                          color: const Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.circular(5)),
                      child: TextButton(
                        onPressed: () {},
                        child: const Center(
                            child: Text(
                          'Update',
                          style: TextStyle(color: Colors.white),
                        )),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void showImagePicker(BuildContext context) {
    showModalBottomSheet(
        context: context,
        builder: (builder) {
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: SizedBox(
              height: MediaQuery.of(context).size.height / 6.5,
              width: MediaQuery.of(context).size.width,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: SizedBox(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () => {PickImage(ImageSource.camera)},
                            icon: const Icon(
                              Icons.camera_alt_outlined,
                              size: 50,
                            ),
                          ),
                          const Text('Camera')
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: SizedBox(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () => {PickImage(ImageSource.gallery)},
                            icon: const Icon(
                              Icons.image,
                              size: 50,
                            ),
                          ),
                          const Text('Gallery')
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        });
  }

  Future<void> PickImage(ImageSource source) async {
    final PIckedFIle = await ImagePicker().pickImage(source: source);
    setState(() {
      _pickedImage = File(PIckedFIle!.path);
    });
  }
}
