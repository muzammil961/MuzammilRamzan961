
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DashBoard extends StatefulWidget {
  const DashBoard({super.key});

  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  var time = DateTime.now();
  @override
  Widget build(BuildContext context) {
    return SafeArea(

      child: Scaffold(

        appBar: AppBar(
          automaticallyImplyLeading: false,
          centerTitle: true,
          title: const Text('DashBoard',style: TextStyle(fontWeight: FontWeight.bold,color: Color.fromRGBO(255, 123, 84, 1)),),

        actions: const [
          CircleAvatar(
              backgroundImage: AssetImage('assets/chef.png')),
          SizedBox(width: 10,)
          ],),
        body: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              children: [
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween ,
                  children: [
                    Container(

                        child: const Row(
                          children: [
                            Text('Welcome, Samz',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                            ),
                            Text('(Admin)')
                          ],
                        )
                    ),
                    Container(

                        child: Text(DateFormat('MMMM d, y').format(time),style: const TextStyle(color: Color.fromRGBO(255, 123, 84, 1),fontFamily: 'Roboto',),)
                    ),


                  ],
                ),
                const SizedBox(height: 5,),
                Container(
                  height: 360,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: 170,
                              width: 176,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end:  Alignment.topRight,
                                      colors: [
                                        Color.fromRGBO(255, 123, 84, 1), Color.fromRGBO(255, 213, 107, 1)
                                      ])
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height:50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(50),
                                          color: const Color.fromRGBO(255, 255, 255, 0.47)
                                      ),
                                      child: const Icon(Icons.dinner_dining_rounded, color: Color.fromRGBO(255, 123, 84, 1),size: 30,),
                                    ),
                                    const SizedBox(height: 16,),
                                    const Text('Total Dine In',style: TextStyle(color: Colors.white,fontSize: 16,),),
                                    const Text('459',style: TextStyle(color: Colors.white,fontSize: 25,),)
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 8,),
                            Container(
                              height: 170,
                              width: 176,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end:  Alignment.topRight,
                                      colors: [
                                        Color.fromRGBO(255, 123, 84, 1), Color.fromRGBO(255, 213, 107, 1)
                                      ])
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height:50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(50),
                                          color: const Color.fromRGBO(255, 255, 255, 0.47)
                                      ),
                                      child: const Icon(Icons.food_bank_outlined, color: Color.fromRGBO(255, 123, 84, 1),size: 30,),
                                    ),
                                    const SizedBox(height: 16,),
                                    const Text('Total Take Away',style: TextStyle(color: Colors.white,fontSize: 16,),),
                                    const Text('459',style: TextStyle(color: Colors.white,fontSize: 25,),)
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 14,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              height: 170,
                              width: 176,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end:  Alignment.topRight,
                                      colors: [
                                        Color.fromRGBO(255, 123, 84, 1), Color.fromRGBO(255, 213, 107, 1)
                                      ])
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height:50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(50),
                                          color: const Color.fromRGBO(255, 255, 255, 0.47)
                                      ),
                                      child: const Icon(Icons.delivery_dining_rounded, color: Color.fromRGBO(255, 123, 84, 1),size: 30,),
                                    ),
                                    const SizedBox(height: 16,),
                                    const Text('Total Delivery',style: TextStyle(color: Colors.white,fontSize: 16,),),
                                    const Text('459',style: TextStyle(color: Colors.white,fontSize: 25,),)
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 8,),
                            Container(
                              height: 170,
                              width: 176,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(20),
                                  gradient: const LinearGradient(
                                      begin: Alignment.topLeft,
                                      end:  Alignment.topRight,
                                      colors: [
                                        Color.fromRGBO(255, 123, 84, 1), Color.fromRGBO(255, 213, 107, 1)
                                      ])
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      height:50,
                                      width: 50,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(50),
                                          color: const Color.fromRGBO(255, 255, 255, 0.47)
                                      ),
                                      child: const Center(child: Text(" \$ ",style: TextStyle(color: Color.fromRGBO(255, 123, 84, 1,),fontSize: 26),)),
                                    ),
                                    const SizedBox(height: 16,),
                                    const Text('Total Revenue',style: TextStyle(color: Colors.white,fontSize: 16,),),
                                    const Text('459',style: TextStyle(color: Colors.white,fontSize: 25,),)
                                  ],
                                ),
                              ),
                            ),


                          ],
                        ),
                      ],
                    ),
                  ) ,
                ),
                const SizedBox(height: 24,),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    height: 400,
                    width: 340,
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1)),
                        borderRadius: BorderRadius.circular(20)
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Center(
                            child: Container(
                              height: 250,
                              width: 200,
                              color: Colors.red,
                            ),
                          ),
                          Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:const Color.fromRGBO(255, 123, 84, 1)
                                ),
                              ),
                              const Text('Dine In'),
                              const SizedBox(width: 3,),
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:const Color.fromRGBO(255, 213, 107, 1)
                                ),
                              ),
                              const Text('Take Away'),
                              const SizedBox(width: 3,),
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:const Color.fromRGBO(255, 178, 107, 1)
                                ),
                              ),
                              const Text('Delivery'),
                              const SizedBox(width: 3,),
                              Container(
                                height: 10,
                                width: 10,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color:const Color.fromRGBO(246, 236, 54, 1)
                                ),
                              ),
                              const Text('Cancel'),
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
