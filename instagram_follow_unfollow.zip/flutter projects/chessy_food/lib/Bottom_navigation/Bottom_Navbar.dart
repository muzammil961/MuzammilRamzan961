import 'package:cherry_food/Home_List/List_Home.dart';
import 'package:flutter/material.dart';

import '../Order_Type/Dine_In.dart';
import 'Profile/Profile.dart';
import 'dashboard.dart';
import '../Add to cart/Cart_Screen.dart';

class Bottom_Navbar extends StatefulWidget {
  const Bottom_Navbar({super.key});

  @override
  State<Bottom_Navbar> createState() => _Bottom_NavbarState();
}

class _Bottom_NavbarState extends State<Bottom_Navbar> {
  int myCurrentIndex = 0;
  List Bottombar = [

    const DashBoard(),
    const List_Home(),
    const Cart_Screen(),
    const Profile_Screen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        floatingActionButtonLocation:
            FloatingActionButtonLocation.miniCenterDocked,
        floatingActionButton: FloatingActionButton(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
          onPressed: () {
            _SelectDialog();
          },
          backgroundColor: Colors.deepOrange,
          child: const Center(
              child: Icon(
            Icons.add,
            color: Colors.white,
          )),
        ),
        body: Bottombar[myCurrentIndex],
        bottomNavigationBar: Container(
          height: 90,
          decoration: const BoxDecoration(color: Colors.transparent),
          alignment: Alignment.topRight,
          child: Center(
            child: Container(
              height: MediaQuery.of(context).size.height,
              decoration: const BoxDecoration(
                boxShadow: [
                  BoxShadow(
                      blurRadius: 5,
                      offset: Offset(3, 3),
                      spreadRadius: 3,
                      color: Colors.black26)
                ],
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(60.0), // Adjust the radius as needed
                  topRight:
                      Radius.circular(60.0), // Adjust the radius as needed
                ),
                color: Colors.white,
              ),
              child: BottomNavigationBar(
                elevation: 0,
                // Set elevation to 0 to avoid shadow overlap
                backgroundColor: Colors.transparent,
                // Set background color to transparent
                currentIndex: myCurrentIndex,
                selectedItemColor: Colors.orange,
                // Selected icon color
                showSelectedLabels: false,
                type: BottomNavigationBarType.fixed,
                onTap: (index) {
                  setState(() {
                    myCurrentIndex = index;
                  });
                },
                items: [
                  BottomNavigationBarItem(
                    icon: Icon(Icons.dashboard,
                        color:
                            myCurrentIndex == 0 ? Colors.orange : Colors.black),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.no_meals_sharp,
                        color:
                            myCurrentIndex == 1 ? Colors.orange : Colors.black,
                        size: 30),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.list_outlined,
                        color:
                            myCurrentIndex == 2 ? Colors.orange : Colors.black,
                        size: 30),
                    label: '',
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.person_outline_outlined,
                        size: 30,
                        color:
                            myCurrentIndex == 3 ? Colors.orange : Colors.black),
                    label: '',
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  void _SelectDialog() {
    // flutter defined function
    showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
            backgroundColor: Colors.white,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Row(
                  children: [
                    Text(
                      'Select Order Type',
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
                const SizedBox(
                  height: 20,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const DineIn_Screen(
                                        title: 'Assign Waiter',
                                      )));
                        },
                        child: InkWell(
                          onTap: () {
                            _Dine_In();
                          },
                          child: Container(
                            height: 60,
                            width: 80,
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: const Color.fromRGBO(255, 123, 84, 1),
                              ),
                            ),
                            child: const Icon(
                              Icons.dinner_dining_rounded,
                              size: 40,
                              color: Color.fromRGBO(255, 123, 84, 1),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () {
                          _Take_Away();
                        },
                        child: Container(
                          height: 60,
                          width: 80,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: const Color.fromRGBO(255, 123, 84, 1),
                            ),
                          ),
                          child: const Icon(
                            size: 40,
                            Icons.food_bank_outlined,
                            color: Color.fromRGBO(255, 123, 84, 1),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () {
                          _Delivery();
                        },
                        child: Container(
                          height: 60,
                          width: 80,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: const Color.fromRGBO(255, 123, 84, 1),
                            ),
                          ),
                          child: const Icon(
                            Icons.delivery_dining_rounded,
                            size: 40,
                            color: Color.fromRGBO(255, 123, 84, 1),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            content: const Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  "Dine In",
                  style: TextStyle(color: Color.fromRGBO(255, 123, 84, 1)),
                ),
                Text(
                  "Take Away",
                  style: TextStyle(color: Color.fromRGBO(255, 123, 84, 1)),
                ),
                Text(
                  "Delivery",
                  style: TextStyle(color: Color.fromRGBO(255, 123, 84, 1)),
                ),
              ],
            ),
          );
        });
  }

  void _Dine_In() {
    // Define lists for waiter options and table numbers
    List<String> waiters = ['Waiter 1', 'Waiter 2', 'Waiter 3'];
    List<String> tableNumbers = ['Table 1', 'Table 2', 'Table 3'];

    // Define variables to hold the selected waiter and table number
    String selectedWaiter = waiters[0]; // Initial value
    String selectedTableNumber = tableNumbers[0]; // Initial value

    // flutter defined function
    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          backgroundColor: Colors.white,
          title: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text(
                            'Dine In',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontFamily: "Roboto",
                              fontSize: 18,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            onPressed: () {
                              Navigator.of(context).pop(true);
                            },
                            icon: const Icon(
                              Icons.close,
                              color: Color.fromRGBO(255, 123, 84, 1),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  // Dropdown for Assign Waiter
                  DropdownButtonFormField<String>(
                    value: selectedWaiter,
                    onChanged: (newValue) {
                      setState(() {
                        selectedWaiter = newValue!;
                      });
                    },
                    items: waiters.map((waiter) {
                      return DropdownMenuItem<String>(
                        value: waiter,
                        child: Text(waiter),
                      );
                    }).toList(),
                    decoration: const InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      labelText: 'Assign Waiter',
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromRGBO(255, 123, 84, 1),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // Dropdown for Table Number
                  DropdownButtonFormField<String>(
                    value: selectedTableNumber,
                    onChanged: (newValue) {
                      setState(() {
                        selectedTableNumber = newValue!;
                      });
                    },
                    items: tableNumbers.map((tableNumber) {
                      return DropdownMenuItem<String>(
                        value: tableNumber,
                        child: Text(tableNumber),
                      );
                    }).toList(),
                    decoration: const InputDecoration(
                      filled: true,
                      fillColor: Colors.white,
                      labelText: 'Table Number',
                      border: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromRGBO(255, 123, 84, 1),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  // TextFormField for Customer Name
                  TextFormField(
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      labelText: 'Customer Name',
                      suffixIcon: IconButton(
                        onPressed: () {
                          debugPrint('do something');
                        },
                        icon: const Icon(
                          Icons.close,
                          color: Color.fromRGBO(255, 123, 84, 1),
                        ),
                      ),
                      hintText: "Customer Name",
                      border: const OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color.fromRGBO(255, 123, 84, 1),
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(5)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: 35,
                        width: 70,
                        decoration: BoxDecoration(
                          color: const Color.fromRGBO(255, 123, 84, 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => const Bottom_Navbar(),
                              ),
                            );
                          },
                          child: const Center(
                            child: Text(
                              'Save',
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _Take_Away() {
    // flutter defined function
    showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
              backgroundColor: Colors.white,
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Take Away',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: "Roboto",
                                    fontSize: 18),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    Navigator.of(context).pop(true);
                                  },
                                  icon: const Icon(Icons.close, color: Colors.black))
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          hintText: "Phone No.",
                          labelText: 'Phone No.',
                          border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          labelText: 'Customer Name',
                          suffixIcon: IconButton(
                              onPressed: () {},
                              icon: const Icon(
                                Icons.close,
                                color: Color.fromRGBO(255, 123, 84, 1),
                              )),
                          hintText: "Customer Name",
                          border: const OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                              height: 35,
                              width: 70,
                              decoration: BoxDecoration(
                                  color: const Color.fromRGBO(255, 123, 84, 1),
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => const Bottom_Navbar()));
                                },
                                child: const Center(
                                    child: Text(
                                  'Save',
                                  style: TextStyle(color: Colors.white),
                                )),
                              ))
                        ],
                      )
                    ],
                  ),
                ],
              ));
        });
  }



  void _Delivery() {
    // flutter defined function
    showDialog(
        context: context,
        builder: (BuildContext context) {
          // return object of type Dialog
          return AlertDialog(
              backgroundColor: Colors.white,
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Delivery',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: "Roboto",
                                    fontSize: 18),
                              ),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              IconButton(
                                  onPressed: () {
                                    Navigator.of(context).pop(true);
                                  },
                                  icon: const Icon(
                                    Icons.close,
                                    color: Color.fromRGBO(255, 123, 84, 1),
                                  ))
                            ],
                          )
                        ],
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          hintText: "Phone No.",
                          labelText: 'Phone No.',
                          border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          labelText: 'Customer Name',
                          hintText: "Customer Name",
                          border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextFormField(
                        decoration: const InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          labelText: 'Assign Rider',
                          hintText: "Assign Rider",
                          border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      TextFormField(
                        maxLines: 2,
                        decoration: const InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          labelText: 'Address',
                          hintText: "Address",
                          border: OutlineInputBorder(
                              borderSide: BorderSide(
                                  color: Color.fromRGBO(255, 123, 84, 1)),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(5))),
                        ),
                      ),
                      const SizedBox(
                        height: 14,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                              height: 35,
                              width: 70,
                              decoration: BoxDecoration(
                                  color: const Color.fromRGBO(255, 123, 84, 1),
                                  borderRadius: BorderRadius.circular(5)),
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => const Bottom_Navbar()));
                                },
                                child: const Center(
                                    child: Text(
                                  'Save',
                                  style: TextStyle(color: Colors.white),
                                )),
                              ))
                        ],
                      )
                    ],
                  ),
                ],
              ));
        });
  }
}
