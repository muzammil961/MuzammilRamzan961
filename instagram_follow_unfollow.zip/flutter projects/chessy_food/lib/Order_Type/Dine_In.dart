
import 'package:flutter/material.dart';

import '../Home_List/List_Home.dart';

class DineIn_Screen extends StatefulWidget {
  final String title;
  const DineIn_Screen({super.key, required this.title});

  @override
  State<DineIn_Screen> createState() => _DineIn_ScreenState();
}

class _DineIn_ScreenState extends State<DineIn_Screen> {

  late String valueChoose;
  List Assign_waiter =[
    'waiter 1', 'waiter 2' , 'waiter 3', 'waiter 4' ,

  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrange,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Container(
                  height: 400,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                            blurRadius: 5,
                            spreadRadius: 1,
                            offset: Offset(1, 1))
                      ]),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Dine In',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "Roboto",
                                  fontSize: 18),
                            ),
                            IconButton(
                                onPressed: () {},
                                icon: const Icon(
                                  Icons.close,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                ))
                          ],
                        ),
                        const SizedBox(
                          height: 50,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            hintText: "Assign Waiter",
                            labelText: 'Assign Waiter',
                            suffixIcon: Table_Number(),
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromRGBO(255, 123, 84, 1)),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5))),
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            labelText: 'Table Number',
                            suffixIcon: Table_Number(),
                            hintText: "Table Number",
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromRGBO(255, 123, 84, 1)),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5))),
                          ),
                        ),
                        const SizedBox(
                          height: 14,
                        ),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            labelText: 'Customer Name',
                            suffixIcon: IconButton(
                                onPressed: () {
                                  debugPrint('do something');
                                },
                                icon: const Icon(
                                  Icons.close,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                )),
                            hintText: "Customer Name",
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(
                                    color: Color.fromRGBO(255, 123, 84, 1)),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(5))),
                          ),
                        ),
                        const SizedBox(
                          height: 14,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                                height: 35,
                                width: 70,
                                decoration: BoxDecoration(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                    borderRadius: BorderRadius.circular(5)),
                                child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) => const List_Home()));
                                  },
                                  child: const Center(
                                      child: Text(
                                    'Save',
                                    style: TextStyle(color: Colors.white),
                                  )),
                                ))
                          ],
                        )
                      ],
                    ),
                  )),
            ),
          ],
        ));
  }
}



class Assign_waiter extends StatefulWidget {
  @override
  _Assign_waiter createState() => _Assign_waiter();
}

class _Assign_waiter extends State<Assign_waiter> {
  String _selectedItem = 'Option 1'; // Default selected item

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: _selectedItem,
      onChanged: (newValue) {
        setState(() {
          _selectedItem = newValue!;
        });
      },
      items: <String>['Option 1', 'Option 2', 'Option 3', 'Option 4']
          .map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}

class Table_Number extends StatefulWidget {
  @override
  _Table_Number createState() => _Table_Number();
}

class _Table_Number extends State<Table_Number> {
  String _selectedItem = 'Option 1'; // Default selected item

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      value: _selectedItem,
      onChanged: (newValue) {
        setState(() {
          _selectedItem = newValue!;
        });
      },
      items: <String>['Option 1', 'Option 2', 'Option 3', 'Option 4']
          .map<DropdownMenuItem<String>>((String value) {
        return DropdownMenuItem<String>(
          value: value,
          child: Text(value),
        );
      }).toList(),
    );
  }
}
