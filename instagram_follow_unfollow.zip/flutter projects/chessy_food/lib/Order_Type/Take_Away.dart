

import 'package:flutter/material.dart';

import '../Home_List/List_Home.dart';


class Take_AwayScreen extends StatefulWidget {
  const Take_AwayScreen({super.key});

  @override
  State<Take_AwayScreen> createState() => _Take_AwayScreenState();
}

class _Take_AwayScreenState extends State<Take_AwayScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrange,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Container(
                  height: 330,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                            blurRadius: 5,

                            spreadRadius: 1,
                            offset: Offset(1, 1)
                        )
                      ]
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Take Away',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold, fontFamily: "Roboto",fontSize: 18),),
                            IconButton(onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(102, 112, 133, 1)))
                          ],),
                        const SizedBox(height: 50,),


                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,

                            filled: true,
                            labelText: 'Phone No.',
                            hintText: "Phone No.",
                            suffixIcon: IconButton(
                                onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(255, 123, 84, 1),

                            )),
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            suffixIcon: IconButton(onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(255, 123, 84, 1),)),
                            hintText: "Customer Name",
                            labelText: 'Customer Name',
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 14,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                                height: 35,
                                width: 70,
                                decoration: BoxDecoration(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                child: TextButton(onPressed: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => const List_Home()));
                                }, child: const Center(child: Text('Save',style: TextStyle(color: Colors.white),)),)
                            )
                          ],)
                      ],
                    ),
                  )
              ),
            ),
          ],
        ));
  }
}
