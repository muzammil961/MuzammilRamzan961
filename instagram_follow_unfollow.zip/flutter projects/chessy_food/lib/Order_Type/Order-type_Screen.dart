
import 'package:cherry_food/Order_Type/Delivery.dart';
import 'package:cherry_food/Order_Type/Dine_In.dart';
import 'package:cherry_food/Order_Type/Take_Away.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Order_Type_Screen extends StatefulWidget {
  const Order_Type_Screen({super.key});

  @override
  State<Order_Type_Screen> createState() => _Order_Type_ScreenState();
}

class _Order_Type_ScreenState extends State<Order_Type_Screen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Container(
                  height: 200,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                            blurRadius: 5,
                            spreadRadius: 1,
                            offset: Offset(1, 1))
                      ]),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.only(left: 30),
                        child: Row(
                          children: [
                            Text(
                              'Select Order Type',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold),
                            )
                          ],
                        ),
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const DineIn_Screen(
                                              title: 'Assign Waiter',
                                            )));
                              },
                              child: Container(
                                height: 60,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                  ),
                                ),
                                child: const Center(
                                  child: Icon(
                                    Icons.dinner_dining,
                                    color: Color.fromRGBO(255, 123, 84, 1),

                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const Take_AwayScreen()));
                              },
                              child: Container(
                                height: 60,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                  ),
                                ),
                                child: const Icon(
                                  Icons.food_bank_outlined,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                ),
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            InkWell(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => const Delivery()));
                              },
                              child: Container(
                                height: 60,
                                width: 100,
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                  ),
                                ),
                                child: const Icon(
                                  Icons.delivery_dining_outlined,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 24),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            SizedBox(
                              height: 20,
                              width: 100,
                              child: Center(
                                  child: Text(
                                    "Dine In",
                                    style: TextStyle(
                                        color: Color.fromRGBO(255, 123, 84, 1)),
                                  )),
                            ),
                            SizedBox(
                              height: 20,
                              width: 100,
                              child: Center(
                                  child: Text(
                                    "Take Away",
                                    style: TextStyle(
                                        color: Color.fromRGBO(255, 123, 84, 1)),
                                  )),
                            ),
                            SizedBox(
                              height: 50,
                              width: 100,
                              child: Center(
                                  child: Text(
                                    "Delivery",
                                    style: TextStyle(
                                        color: Color.fromRGBO(255, 123, 84, 1)),
                                  )),
                            ),
                            SizedBox(
                              width: 10,
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
