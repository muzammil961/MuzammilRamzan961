
import 'package:flutter/material.dart';

import '../Home_List/List_Home.dart';

class Delivery extends StatefulWidget {
  const Delivery({super.key});

  @override
  State<Delivery> createState() => _DeliveryState();
}

class _DeliveryState extends State<Delivery> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.deepOrange,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Container(
                  height: 550,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                            blurRadius: 5,

                            spreadRadius: 1,
                            offset: Offset(1, 1)
                        )
                      ]
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Column(

                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Delivery',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold, fontFamily: "Roboto",fontSize: 18),),
                            IconButton(onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(255, 123, 84, 1),))
                          ],),
                        const SizedBox(height: 50,),


                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,

                            filled: true,
                            hintText: "Phone No.",
                            labelText: 'Phone No.',
                            suffixIcon: IconButton(onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(255, 123, 84, 1),)),
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            labelText: 'Customer Name',
                            suffixIcon: IconButton(onPressed: (){}, icon: const Icon(Icons.close,color: Color.fromRGBO(255, 123, 84, 1),)),
                            hintText: "Customer Name",
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 10,),
                        TextFormField(
                          decoration: InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            labelText: 'Assign Rider',
                            suffixIcon: PopupMenuButton(
                                icon: const Icon(Icons.expand_more),
                                itemBuilder: (context) =>  [
                              const PopupMenuItem(

                                value: 1,

                                child: Text('rider 1'),
                              ),
                              const PopupMenuItem(

                                value: 2,

                                child: Text('rider 2'),)
                            ]),
                            hintText: "Assign Rider",
                            border: const OutlineInputBorder(
                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 10,),
                        TextFormField(
                          maxLines: 3,
                          decoration: const InputDecoration(
                            fillColor: Colors.white,
                            filled: true,
                            labelText: 'Address',


                            hintText: "Address",
                            border: OutlineInputBorder(

                                borderSide: BorderSide(

                                    color: Color.fromRGBO(255, 123, 84, 1)
                                ),
                                borderRadius: BorderRadius.all(Radius.circular(5))),

                          ),
                        ),
                        const SizedBox(height: 10,),


                        const SizedBox(height: 20,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                                height: 35,
                                width: 70,
                                decoration: BoxDecoration(
                                    color: const Color.fromRGBO(255, 123, 84, 1),
                                    borderRadius: BorderRadius.circular(5)
                                ),
                                child: TextButton(onPressed: (){
                                  Navigator.push(context, MaterialPageRoute(builder: (context) => const List_Home()));
                                }, child: const Center(child: Text('Save',style: TextStyle(color: Colors.white),)),)
                            )
                          ],)
                      ],
                    ),
                  )
              ),
            ),
          ],
        ));
  }
}

