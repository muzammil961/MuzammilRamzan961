

import 'package:flutter/material.dart';

class Categories extends StatefulWidget {
  const Categories({super.key});

  @override
  State<Categories> createState() => _CategoriesState();
}

class _CategoriesState extends State<Categories> {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: 800,
        width: 350,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1))
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Center(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Categories',style: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),),
                    IconButton(onPressed: (){
                      Navigator.pop(context);
                    }, icon: const Icon(Icons.close))
                  ],
                ),
                const SizedBox(height: 40,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('A',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('B',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),

                      ),
                      child: const Center(child: Text('A',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 35,
                      width: 110,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Appetizer',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    Container(
                      height: 35,
                      width: 80,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('BBQ',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    Container(
                      height: 35,
                      width: 110,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Beverages',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 35,
                      width: 110,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Appetizer',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('C',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),

                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 35,
                      width: 180,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Chef’s Special Menu',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 90,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Chicken',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 35,
                      width: 190,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Chicken Handi Boneless',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 121,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Chocolate',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(

                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('F',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                    const SizedBox(width: 170,),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('F',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),


                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 35,
                      width: 130,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Fish (Seasonal)',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 52,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Fries',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 110,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Mutton & Beef',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('P',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      height: 35,
                      width: 100,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Pasta',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    Container(
                      height: 35,
                      width: 100,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Pasta',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    Container(
                      height: 35,
                      width: 100,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Pizza',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),


                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('R',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                    const SizedBox(width: 60,),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('S',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(

                  children: [
                    Container(
                      height: 35,
                      width: 80,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Rice',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 80,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Salad',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 102,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Sandwich',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),


                  ],
                ),
                const SizedBox(height: 10,),
                Row(

                  children: [
                    Container(
                      height: 35,
                      width: 109,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Shawarma',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),
                    const SizedBox(width: 14,),
                    Container(
                      height: 35,
                      width: 179,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Shawarma Platers',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),



                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  children: [
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('T',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                    const SizedBox(width: 220,),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: const Color.fromRGBO(255, 123, 84, 1),
                      ),
                      child: const Center(child: Text('W',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 20),)),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,

                  children: [
                    Container(
                      height: 35,
                      width: 90,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Tandoori',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),

                    Container(
                      height: 35,
                      width: 132,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Tortilla Wraps',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),

                    Container(
                      height: 35,
                      width: 81,

                      decoration: BoxDecoration(
                        border: Border.all(color: const Color.fromRGBO(255, 123, 84, 1),),
                        borderRadius: BorderRadius.circular(5),

                      ),
                      child: const Center(child: Text('Wings',style: TextStyle(color: Colors.black,fontSize: 14),)),
                    ),


                  ],
                ),






              ],
            ),
          ),
        ),
      ),
    );
  }
}
