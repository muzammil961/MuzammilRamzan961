

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Forget_Password extends StatefulWidget {
  const Forget_Password({super.key});

  @override
  State<Forget_Password> createState() => _Forget_PasswordState();
}

class _Forget_PasswordState extends State<Forget_Password> {
  final Forget_PasswordController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return  SafeArea(

      child: Scaffold(
        backgroundColor: Colors.deepOrange,
        appBar: AppBar(
          backgroundColor: Colors.white,
          centerTitle: true,
          title: const Text("Forget Passsword"),
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(

                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    hintText: "Enter Email",
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(40)),
                    prefixIcon: const Icon(
                      Icons.email_outlined,
                      color: Color.fromRGBO(255, 123, 84, 1),
                    ),
                  )),
              const SizedBox(height: 40,),
              TextButton(
                onPressed: () {

                },
                child: Container(
                    height: 50,
                    decoration: BoxDecoration(
                        color: const Color.fromRGBO(255, 213, 107, 1),
                        borderRadius: BorderRadius.circular(40)),
                    child: const Center(
                        child: Text(
                          'Reset Password',
                          style: TextStyle(color: Colors.white),
                        ))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
