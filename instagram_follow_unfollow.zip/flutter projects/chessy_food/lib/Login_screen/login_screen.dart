import 'package:cherry_food/Bottom_navigation/Bottom_Navbar.dart';

import 'package:cherry_food/Login_screen/SignUp_screen.dart';
import 'package:cherry_food/Login_screen/forget_screen.dart';

import 'package:flutter/material.dart';

class Login_Screen extends StatefulWidget {
  const Login_Screen({super.key});

  @override
  State<Login_Screen> createState() => _Login_ScreenState();
}

class _Login_ScreenState extends State<Login_Screen> {
  final EmailController = TextEditingController();
  final PasswordController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    EmailController.dispose();
    PasswordController.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color.fromRGBO(255, 213, 107, 1),
      body: SafeArea(
          child: Container(
        height: double.infinity,
        width: double.infinity,
        child: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              height: 270,
              child: Container(
                height: 300,
                width: 393,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: AssetImage("assets/fire.png"))),
                child: const Image(image: AssetImage("assets/cheesy.png")),
              ),
            ),
            Positioned(
                top: 240,
                child: Container(
                  width: MediaQuery.sizeOf(context).width,
                  height: 1000,
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topRight: Radius.circular(30),
                          topLeft: Radius.circular(30)),
                      color: Colors.deepOrange),
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          const SizedBox(
                            height: 20,
                          ),
                          const Text(
                            "Welcome Back!",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 30,
                                fontFamily: 'Roboto'),
                          ),
                          const SizedBox(
                            height: 40,
                          ),
                          const Padding(
                            padding: EdgeInsets.only(left: 20),
                            child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Login",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontFamily: "Roboto",
                                        fontSize: 18),
                                  )
                                ]),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                              controller: EmailController,
                              keyboardType: TextInputType.emailAddress,
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                hintText: "Enter Email",
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40)),
                                prefixIcon: const Icon(
                                  Icons.email_outlined,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                ),
                              )),
                          const SizedBox(
                            height: 10,
                          ),
                          TextFormField(
                              controller: PasswordController,
                              decoration: InputDecoration(
                                fillColor: Colors.white,
                                filled: true,
                                hintText: "Enter Password",
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(40)),
                                suffixIcon: const Icon(Icons.remove_red_eye),
                                prefixIcon: const Icon(
                                  Icons.lock,
                                  color: Color.fromRGBO(255, 123, 84, 1),
                                ),
                              )),
                          const SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                const Forget_Password()));
                                  },
                                  child: const Text("forget password",
                                      style: TextStyle(
                                          color: Color.fromRGBO(
                                              255, 213, 107, 1))))
                            ],
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          const Bottom_Navbar()));
                            },
                            child: Container(
                                height: 50,
                                decoration: BoxDecoration(
                                    color:
                                        const Color.fromRGBO(255, 213, 107, 1),
                                    borderRadius: BorderRadius.circular(40)),
                                child: const Center(
                                    child: Text(
                                  'Login',
                                  style: TextStyle(color: Colors.white),
                                ))),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Column(
                            children: [
                              const Text("if you don't have an account"),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Text('You can'),
                                  TextButton(
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    const SignUp_Screen()));
                                      },
                                      child: const Text(
                                        "Request For a Service",
                                        style: TextStyle(
                                            color: Color.fromRGBO(
                                                255, 213, 107, 1)),
                                      ))
                                ],
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                )),
          ],
        ),
      )),
    );
  }
}
