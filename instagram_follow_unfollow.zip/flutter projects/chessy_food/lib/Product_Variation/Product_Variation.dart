

import 'package:flutter/material.dart';

class Product_Variation extends StatefulWidget {
  const Product_Variation({super.key});

  @override
  State<Product_Variation> createState() => _Product_VariationState();
}

class _Product_VariationState extends State<Product_Variation> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 400,
            child: Column(
              children: [

              ],
            ),
          ),

        ],
      )
    );
  }
}
