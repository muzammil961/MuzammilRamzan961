
import 'package:flutter/material.dart';
import 'package:persistent_shopping_cart/model/cart_model.dart';
import 'package:persistent_shopping_cart/persistent_shopping_cart.dart';


import '../Add to cart/Cart_Model.dart';
import '../Add to cart/Network_image.dart';


class Grid_Screen extends StatelessWidget {
  const Grid_Screen({super.key});

  @override
  Widget build(BuildContext context) {
    PersistentShoppingCart cart = PersistentShoppingCart();

    List<ItemModel> itemsList = const [
      ItemModel(
          productId: '1',
          productName: 'Arabian Burger',
          productDescription: 'Burger',
          productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
          unitPrice: 350),
      ItemModel(
          productId: '2',
          productName: 'Chicken Fajita',
          productDescription: 'Pizza',
          productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          unitPrice: 350),
      ItemModel(
          productId: '3',
          productName: 'Arabian Burger',
          productDescription: 'Burger',
          productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
          unitPrice: 350),
      ItemModel(
          productId: '4',
          productName: 'Chicken Fajita',
          productDescription: 'Pizza',
          productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          unitPrice: 350),
      ItemModel(
          productId: '5',
          productName: 'Arabian Burger',
          productDescription: 'Burger',
          productThumbnail: 'https://media.istockphoto.com/id/1532801623/photo/tasty-fresh-burger-isolated-on-white-background.jpg?s=1024x1024&w=is&k=20&c=5Po7mGXjhEap5NP1qD7GVikP6O94l0ag13EtS2eTz_k=',
          unitPrice: 350),
      ItemModel(
          productId: '6',
          productName: 'Chicken Fajita',
          productDescription: 'Pizza',
          productThumbnail: 'https://images.unsplash.com/photo-1604382355076-af4b0eb60143?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
          unitPrice: 350),
    ];
    return GridView.builder(
      itemCount: itemsList.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2,mainAxisSpacing: 12, crossAxisSpacing: 12),
      itemBuilder: (BuildContext context, int index) {
        final item = itemsList[index];
        return Container(
          height: 210,
          width: 190,
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [

                BoxShadow(
                    color: Colors.grey.withOpacity(0.1),
                    blurRadius: 05,
                    spreadRadius: 5,
                    offset: const Offset(5, 5))
              ]
          ),
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.11,
                width: MediaQuery.of(context).size.width * 0.4,
                decoration: const BoxDecoration(


                ),
                child: NetworkImageWidget(

                    height: 100,
                    width: 100,
                    imageUrl: item.productThumbnail),
              ),

              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(

                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.productName,
                            style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold),
                          ),
                          Text(
                            item.productDescription,
                            style: const TextStyle(
                              fontSize: 14,
                            ),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                r"Rs " + item.unitPrice.toString(),
                                style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                              ),
                              Container(

                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(40),
                                    color:       const Color.fromRGBO(255, 123, 84, 1)
                                ),
                                child: PersistentShoppingCart()
                                    .showAndUpdateCartItemWidget(
                                    inCartWidget: const Text('-',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 12),),
                                    notInCartWidget:
                                    const Icon(Icons.add,color:  Colors.white,size: 15,),                                     product: PersistentShoppingCartItem(
                                    productId: item.productId,
                                    productName: item.productName,
                                    unitPrice: double.parse(
                                        item.unitPrice.toString()),
                                    quantity: 1,
                                    productThumbnail:
                                    item.productThumbnail,
                                    productDescription: item.productDescription)),
                              ),
                            ],
                          )

                        ],
                      ),
                    ),

                  ],
                ),
              )
            ],
          ),
        );
      },


    );
  }




}
